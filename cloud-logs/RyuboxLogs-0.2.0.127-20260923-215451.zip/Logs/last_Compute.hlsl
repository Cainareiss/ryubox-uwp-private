RWByteAddressBuffer _6 : register(u5, space4);

void main_inner()
{
    _6.Store(0, 42u);
}

[numthreads(1, 1, 1)]
void main()
{
    main_inner();
}
