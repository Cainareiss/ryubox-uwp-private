cbuffer support_buffer : register(b0, space0)
{
    uint support_buffer_1_m0 : packoffset(c0);
    uint support_buffer_1_m1[8] : packoffset(c1);
    float4 support_buffer_1_m2 : packoffset(c9);
    float4 support_buffer_1_m3 : packoffset(c10);
    int support_buffer_1_m4 : packoffset(c11);
    float support_buffer_1_m5[73] : packoffset(c12);
    int4 support_buffer_1_m6 : packoffset(c85);
    int support_buffer_1_m7 : packoffset(c86);
};

cbuffer vp_c3 : register(b1, space0)
{
    float4 vp_c3_1_m0[4096] : packoffset(c0);
};


static float4 gl_Position;
static float gl_PointSize;
static float4 _22;
static float4 _24;
static float4 _27;
static float4 _29;
static float4 _31;

struct SPIRV_Cross_Input
{
    float4 _27 : TEXCOORD0;
    float4 _31 : TEXCOORD1;
    float4 _29 : TEXCOORD2;
};

struct SPIRV_Cross_Output
{
    float4 _22 : TEXCOORD0;
    float4 _24 : TEXCOORD1;
    float4 ryubox_link_dummy2 : TEXCOORD2;
    float4 ryubox_link_dummy3 : TEXCOORD3;
    float4 ryubox_link_dummy4 : TEXCOORD4;
    float4 ryubox_link_dummy5 : TEXCOORD5;
    float4 ryubox_link_dummy6 : TEXCOORD6;
    float4 ryubox_link_dummy7 : TEXCOORD7;
    float4 ryubox_link_dummy8 : TEXCOORD8;
    float4 ryubox_link_dummy9 : TEXCOORD9;
    float4 ryubox_link_dummy10 : TEXCOORD10;
    float4 ryubox_link_dummy11 : TEXCOORD11;
    float4 ryubox_link_dummy12 : TEXCOORD12;
    float4 ryubox_link_dummy13 : TEXCOORD13;
    float4 ryubox_link_dummy14 : TEXCOORD14;
    float4 ryubox_link_dummy15 : TEXCOORD15;
    float4 gl_Position : SV_Position;
};

void main_inner()
{
    gl_PointSize = 1.0f;
    gl_Position.x = 0.0f;
    gl_Position.y = 0.0f;
    gl_Position.z = 0.0f;
    gl_Position.w = 1.0f;
    _22.x = 0.0f;
    _22.y = 0.0f;
    _22.z = 0.0f;
    _22.w = 1.0f;
    _24.x = 0.0f;
    _24.y = 0.0f;
    float _45 = _27.y;
    float _47 = _27.x;
    float _49 = _27.z;
    float _51 = _29.y;
    float _53 = _29.x;
    precise float _171 = _45 * vp_c3_1_m0[1].y;
    float _55 = _171;
    float _57 = _31.x;
    precise float _177 = _45 * vp_c3_1_m0[1].x;
    float _59 = _177;
    float _61 = _31.y;
    float _63 = mad(_47, vp_c3_1_m0[0].y, _55);
    float _65 = _31.z;
    float _67 = mad(_47, vp_c3_1_m0[0].x, _59);
    float _69 = _31.w;
    float _71 = mad(_49, vp_c3_1_m0[2].y, _63);
    precise float _203 = _45 * vp_c3_1_m0[1].z;
    float _73 = _203;
    precise float _207 = _45 * vp_c3_1_m0[1].w;
    float _75 = _207;
    float _77 = mad(_49, vp_c3_1_m0[2].x, _67);
    precise float _216 = _71 + vp_c3_1_m0[3].y;
    float _79 = _216;
    float _81 = mad(_47, vp_c3_1_m0[0].z, _73);
    float _83 = mad(_47, vp_c3_1_m0[0].w, _75);
    float _85 = mad(_51, vp_c3_1_m0[9].y, vp_c3_1_m0[9].w);
    precise float _237 = _77 + vp_c3_1_m0[3].x;
    float _87 = _237;
    _24.y = _85;
    precise float _244 = _79 * vp_c3_1_m0[5].x;
    float _89 = _244;
    float _91 = mad(_53, vp_c3_1_m0[9].x, vp_c3_1_m0[9].z);
    float _93 = mad(_49, vp_c3_1_m0[2].z, _81);
    _24.x = _91;
    float _95 = mad(_49, vp_c3_1_m0[2].w, _83);
    precise float _267 = _57 * vp_c3_1_m0[8].x;
    float _97 = _267;
    precise float _271 = _79 * vp_c3_1_m0[5].y;
    float _99 = _271;
    _22.x = _97;
    float _101 = mad(_87, vp_c3_1_m0[4].x, _89);
    precise float _283 = _79 * vp_c3_1_m0[5].z;
    float _103 = _283;
    precise float _287 = _79 * vp_c3_1_m0[5].w;
    float _105 = _287;
    precise float _291 = _69 * vp_c3_1_m0[8].w;
    float _107 = _291;
    precise float _295 = _93 + vp_c3_1_m0[3].z;
    float _109 = _295;
    _22.w = _107;
    float _111 = mad(_87, vp_c3_1_m0[4].y, _99);
    float _113 = mad(_87, vp_c3_1_m0[4].z, _103);
    float _115 = mad(_87, vp_c3_1_m0[4].w, _105);
    precise float _316 = _95 + vp_c3_1_m0[3].w;
    float _117 = _316;
    float _119 = mad(_109, vp_c3_1_m0[6].x, _101);
    float _121 = mad(_109, vp_c3_1_m0[6].y, _111);
    float _123 = mad(_109, vp_c3_1_m0[6].z, _113);
    float _125 = mad(_109, vp_c3_1_m0[6].w, _115);
    precise float _341 = _61 * vp_c3_1_m0[8].y;
    float _127 = _341;
    precise float _345 = _65 * vp_c3_1_m0[8].z;
    float _129 = _345;
    _22.y = _127;
    float _131 = mad(_117, vp_c3_1_m0[7].x, _119);
    _22.z = _129;
    float _133 = mad(_117, vp_c3_1_m0[7].y, _121);
    gl_Position.x = _131;
    float _135 = mad(_117, vp_c3_1_m0[7].z, _123);
    gl_Position.y = _133;
    float _137 = mad(_117, vp_c3_1_m0[7].w, _125);
    gl_Position.z = _135;
    gl_Position.w = _137;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    _27 = stage_input._27;
    _29 = stage_input._29;
    _31 = stage_input._31;
    main_inner();
    SPIRV_Cross_Output stage_output;
        stage_output.ryubox_link_dummy2 = gl_Position;
        stage_output.ryubox_link_dummy3 = gl_Position;
        stage_output.ryubox_link_dummy4 = gl_Position;
        stage_output.ryubox_link_dummy5 = gl_Position;
        stage_output.ryubox_link_dummy6 = gl_Position;
        stage_output.ryubox_link_dummy7 = gl_Position;
        stage_output.ryubox_link_dummy8 = gl_Position;
        stage_output.ryubox_link_dummy9 = gl_Position;
        stage_output.ryubox_link_dummy10 = gl_Position;
        stage_output.ryubox_link_dummy11 = gl_Position;
        stage_output.ryubox_link_dummy12 = gl_Position;
        stage_output.ryubox_link_dummy13 = gl_Position;
        stage_output.ryubox_link_dummy14 = gl_Position;
        stage_output.ryubox_link_dummy15 = gl_Position;

    stage_output.gl_Position = gl_Position;
    stage_output._22 = _22;
    stage_output._24 = _24;
    return stage_output;
}
