cbuffer support_buffer : register(b0, space0)
{
    uint support_buffer_1_m0 : packoffset(c0);
    uint support_buffer_1_m1[8] : packoffset(c1);
    float4 support_buffer_1_m2 : packoffset(c9);
    float4 support_buffer_1_m3 : packoffset(c10);
    int support_buffer_1_m4 : packoffset(c11);
    float support_buffer_1_m5[73] : packoffset(c12);
    int4 support_buffer_1_m6 : packoffset(c85);
    int support_buffer_1_m7 : packoffset(c86);
};

cbuffer cp_c0 : register(b1, space0)
{
    float4 cp_c0_1_m0[4096] : packoffset(c0);
};

RWByteAddressBuffer cp_s0 : register(u0, space1);
RWByteAddressBuffer cp_s1 : register(u1, space1);

static uint3 gl_WorkGroupID;
static uint3 gl_LocalInvocationID;
struct SPIRV_Cross_Input
{
    uint3 gl_WorkGroupID : SV_GroupID;
    uint3 gl_LocalInvocationID : SV_GroupThreadID;
};

void main_inner()
{
    float _39 = asfloat(gl_WorkGroupID.x);
    float _41 = asfloat(gl_LocalInvocationID.x);
    float _43 = asfloat(gl_WorkGroupID.y);
    float _45 = asfloat(gl_LocalInvocationID.y);
    int _48 = asint(_39) << 4;
    int _50 = _48 + asint(_41);
    bool _54 = uint(_50) >= asuint(cp_c0_1_m0[0].x);
    int _56 = asint(_43) << 4;
    int _58 = _56 + asint(_45);
    if (_54)
    {
        return;
    }
    bool _60 = uint(_58) >= asuint(cp_c0_1_m0[0].y);
    if (_60)
    {
        return;
    }
    int _62 = _50 << 4;
    int _64 = _58 & 65535;
    uint _67 = uint(int(uint(asint(cp_c0_1_m0[1].z)) >> uint(16)));
    int _69 = _64 * int(_67);
    int _71 = _69 & 65535;
    int _73 = asint(cp_c0_1_m0[1].z) << 16;
    int _75 = _71 | _73;
    int _77 = _58 & 65535;
    int _79 = asint(cp_c0_1_m0[1].z) & 65535;
    int _81 = _77 * _79;
    int _83 = _81 + _62;
    uint _85 = uint(int(uint(_58) >> uint(16)));
    uint _87 = uint(int(uint(_75) >> uint(16)));
    int _89 = int(_85) * int(_87);
    int _91 = _89 << 16;
    int _93 = _75 << 16;
    int _95 = _83 + _93;
    int _97 = _91 + _95;
    uint _99 = uint(int(uint(_97) >> uint(2)));
    float _101 = asfloat(cp_s0.Load(int(_99) * 4 + 0));
    int _103 = _97 + 4;
    uint _105 = uint(int(uint(_103) >> uint(2)));
    float _107 = asfloat(cp_s0.Load(int(_105) * 4 + 0));
    int _109 = _97 + 8;
    uint _111 = uint(int(uint(_109) >> uint(2)));
    float _113 = asfloat(cp_s0.Load(int(_111) * 4 + 0));
    int _115 = _97 + 12;
    uint _117 = uint(int(uint(_115) >> uint(2)));
    float _119 = asfloat(cp_s0.Load(int(_117) * 4 + 0));
    int _121 = _58 & 65535;
    uint _123 = uint(int(uint(asint(cp_c0_1_m0[1].w)) >> uint(16)));
    int _125 = _121 * int(_123);
    int _127 = _125 & 65535;
    int _129 = asint(cp_c0_1_m0[1].w) << 16;
    int _131 = _127 | _129;
    int _133 = _58 & 65535;
    int _135 = asint(cp_c0_1_m0[1].w) & 65535;
    int _137 = _133 * _135;
    int _139 = _137 + _62;
    uint _141 = uint(int(uint(_58) >> uint(16)));
    uint _143 = uint(int(uint(_131) >> uint(16)));
    int _145 = int(_141) * int(_143);
    int _147 = _145 << 16;
    int _149 = _131 << 16;
    int _151 = _139 + _149;
    int _153 = _147 + _151;
    uint _155 = uint(int(uint(_153) >> uint(2)));
    cp_s1.Store(int(_155) * 4 + 0, asuint(_101));
    int _157 = _153 + 4;
    uint _159 = uint(int(uint(_157) >> uint(2)));
    cp_s1.Store(int(_159) * 4 + 0, asuint(_107));
    int _161 = _153 + 8;
    uint _163 = uint(int(uint(_161) >> uint(2)));
    cp_s1.Store(int(_163) * 4 + 0, asuint(_113));
    int _165 = _153 + 12;
    uint _167 = uint(int(uint(_165) >> uint(2)));
    cp_s1.Store(int(_167) * 4 + 0, asuint(_119));
}

[numthreads(16, 1, 1)]
void main(SPIRV_Cross_Input stage_input)
{
    gl_WorkGroupID = stage_input.gl_WorkGroupID;
    gl_LocalInvocationID = stage_input.gl_LocalInvocationID;
    main_inner();
}
