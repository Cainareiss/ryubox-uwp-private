cbuffer support_buffer : register(b0, space0)
{
    uint support_buffer_1_m0 : packoffset(c0);
    uint support_buffer_1_m1[8] : packoffset(c1);
    float4 support_buffer_1_m2 : packoffset(c9);
    float4 support_buffer_1_m3 : packoffset(c10);
    int support_buffer_1_m4 : packoffset(c11);
    float support_buffer_1_m5[73] : packoffset(c12);
    int4 support_buffer_1_m6 : packoffset(c85);
    int support_buffer_1_m7 : packoffset(c86);
};


static float4 gl_PositionIn[3];
static float4 gl_Position;
static uint gl_Layer;
static float4 _18[3];
static float4 _21;
static float4 _26[3];
static float4 _28;

struct SPIRV_Cross_Input
{
    float4 _18 : TEXCOORD0;
    float4 _26 : TEXCOORD1;
    float4 ryubox_link_input_dummy2 : TEXCOORD2;
    float4 ryubox_link_input_dummy3 : TEXCOORD3;
    float4 ryubox_link_input_dummy4 : TEXCOORD4;
    float4 ryubox_link_input_dummy5 : TEXCOORD5;
    float4 ryubox_link_input_dummy6 : TEXCOORD6;
    float4 ryubox_link_input_dummy7 : TEXCOORD7;
    float4 ryubox_link_input_dummy8 : TEXCOORD8;
    float4 ryubox_link_input_dummy9 : TEXCOORD9;
    float4 ryubox_link_input_dummy10 : TEXCOORD10;
    float4 ryubox_link_input_dummy11 : TEXCOORD11;
    float4 ryubox_link_input_dummy12 : TEXCOORD12;
    float4 ryubox_link_input_dummy13 : TEXCOORD13;
    float4 ryubox_link_input_dummy14 : TEXCOORD14;
    float4 ryubox_link_input_dummy15 : TEXCOORD15;
    float4 gl_PositionIn : SV_Position;
};

struct SPIRV_Cross_Output
{
    float4 _21 : TEXCOORD0;
    float4 _28 : TEXCOORD1;
    float4 ryubox_link_dummy2 : TEXCOORD2;
    float4 ryubox_link_dummy3 : TEXCOORD3;
    float4 ryubox_link_dummy4 : TEXCOORD4;
    float4 ryubox_link_dummy5 : TEXCOORD5;
    float4 ryubox_link_dummy6 : TEXCOORD6;
    float4 ryubox_link_dummy7 : TEXCOORD7;
    float4 ryubox_link_dummy8 : TEXCOORD8;
    float4 ryubox_link_dummy9 : TEXCOORD9;
    float4 ryubox_link_dummy10 : TEXCOORD10;
    float4 ryubox_link_dummy11 : TEXCOORD11;
    float4 ryubox_link_dummy12 : TEXCOORD12;
    float4 ryubox_link_dummy13 : TEXCOORD13;
    float4 ryubox_link_dummy14 : TEXCOORD14;
    float4 ryubox_link_dummy15 : TEXCOORD15;
    uint gl_Layer : SV_RenderTargetArrayIndex;
    float4 gl_Position : SV_Position;
};

void main_inner(triangle SPIRV_Cross_Input stage_input[3], inout TriangleStream<SPIRV_Cross_Output> geometry_stream)
{
    float _47 = _18[0].x;
    _21.x = _47;
    float _49 = _18[0].y;
    gl_Layer = asint(_49);
    float _51 = _18[0].z;
    _21.z = _51;
    float _53 = _18[0].w;
    _21.w = _53;
    float _55 = _26[0].x;
    _28.x = _55;
    float _57 = _26[0].y;
    _28.y = _57;
    float _59 = _26[0].z;
    _28.z = _59;
    float _61 = _26[0].w;
    _28.w = _61;
    float _63 = gl_PositionIn[0].x;
    gl_Position.x = _63;
    float _65 = gl_PositionIn[0].y;
    gl_Position.y = _65;
    float _67 = gl_PositionIn[0].z;
    gl_Position.z = _67;
    float _69 = gl_PositionIn[0].w;
    gl_Position.w = _69;
    {
        SPIRV_Cross_Output stage_output;
        stage_output.ryubox_link_dummy2 = gl_Position;
        stage_output.ryubox_link_dummy3 = gl_Position;
        stage_output.ryubox_link_dummy4 = gl_Position;
        stage_output.ryubox_link_dummy5 = gl_Position;
        stage_output.ryubox_link_dummy6 = gl_Position;
        stage_output.ryubox_link_dummy7 = gl_Position;
        stage_output.ryubox_link_dummy8 = gl_Position;
        stage_output.ryubox_link_dummy9 = gl_Position;
        stage_output.ryubox_link_dummy10 = gl_Position;
        stage_output.ryubox_link_dummy11 = gl_Position;
        stage_output.ryubox_link_dummy12 = gl_Position;
        stage_output.ryubox_link_dummy13 = gl_Position;
        stage_output.ryubox_link_dummy14 = gl_Position;
        stage_output.ryubox_link_dummy15 = gl_Position;

        stage_output.gl_Position = gl_Position;
        stage_output.gl_Layer = gl_Layer;
        stage_output._21 = _21;
        stage_output._28 = _28;
        geometry_stream.Append(stage_output);
    }
    float _71 = _18[1].x;
    _21.x = _71;
    float _73 = _18[1].y;
    gl_Layer = asint(_73);
    float _75 = _18[1].z;
    _21.z = _75;
    float _77 = _18[1].w;
    _21.w = _77;
    float _79 = _26[1].x;
    _28.x = _79;
    float _81 = _26[1].y;
    _28.y = _81;
    float _83 = _26[1].z;
    _28.z = _83;
    float _85 = _26[1].w;
    _28.w = _85;
    float _87 = gl_PositionIn[1].x;
    gl_Position.x = _87;
    float _89 = gl_PositionIn[1].y;
    gl_Position.y = _89;
    float _91 = gl_PositionIn[1].z;
    gl_Position.z = _91;
    float _93 = gl_PositionIn[1].w;
    gl_Position.w = _93;
    {
        SPIRV_Cross_Output stage_output;
        stage_output.ryubox_link_dummy2 = gl_Position;
        stage_output.ryubox_link_dummy3 = gl_Position;
        stage_output.ryubox_link_dummy4 = gl_Position;
        stage_output.ryubox_link_dummy5 = gl_Position;
        stage_output.ryubox_link_dummy6 = gl_Position;
        stage_output.ryubox_link_dummy7 = gl_Position;
        stage_output.ryubox_link_dummy8 = gl_Position;
        stage_output.ryubox_link_dummy9 = gl_Position;
        stage_output.ryubox_link_dummy10 = gl_Position;
        stage_output.ryubox_link_dummy11 = gl_Position;
        stage_output.ryubox_link_dummy12 = gl_Position;
        stage_output.ryubox_link_dummy13 = gl_Position;
        stage_output.ryubox_link_dummy14 = gl_Position;
        stage_output.ryubox_link_dummy15 = gl_Position;

        stage_output.gl_Position = gl_Position;
        stage_output.gl_Layer = gl_Layer;
        stage_output._21 = _21;
        stage_output._28 = _28;
        geometry_stream.Append(stage_output);
    }
    float _95 = _18[2].x;
    _21.x = _95;
    float _97 = _18[2].y;
    gl_Layer = asint(_97);
    float _99 = _18[2].z;
    _21.z = _99;
    float _101 = _18[2].w;
    _21.w = _101;
    float _103 = _26[2].x;
    _28.x = _103;
    float _105 = _26[2].y;
    _28.y = _105;
    float _107 = _26[2].z;
    _28.z = _107;
    float _109 = _26[2].w;
    _28.w = _109;
    float _111 = gl_PositionIn[2].x;
    gl_Position.x = _111;
    float _113 = gl_PositionIn[2].y;
    gl_Position.y = _113;
    float _115 = gl_PositionIn[2].z;
    gl_Position.z = _115;
    float _117 = gl_PositionIn[2].w;
    gl_Position.w = _117;
    {
        SPIRV_Cross_Output stage_output;
        stage_output.ryubox_link_dummy2 = gl_Position;
        stage_output.ryubox_link_dummy3 = gl_Position;
        stage_output.ryubox_link_dummy4 = gl_Position;
        stage_output.ryubox_link_dummy5 = gl_Position;
        stage_output.ryubox_link_dummy6 = gl_Position;
        stage_output.ryubox_link_dummy7 = gl_Position;
        stage_output.ryubox_link_dummy8 = gl_Position;
        stage_output.ryubox_link_dummy9 = gl_Position;
        stage_output.ryubox_link_dummy10 = gl_Position;
        stage_output.ryubox_link_dummy11 = gl_Position;
        stage_output.ryubox_link_dummy12 = gl_Position;
        stage_output.ryubox_link_dummy13 = gl_Position;
        stage_output.ryubox_link_dummy14 = gl_Position;
        stage_output.ryubox_link_dummy15 = gl_Position;

        stage_output.gl_Position = gl_Position;
        stage_output.gl_Layer = gl_Layer;
        stage_output._21 = _21;
        stage_output._28 = _28;
        geometry_stream.Append(stage_output);
    }
    geometry_stream.RestartStrip();
}

[maxvertexcount(3)]
void main(triangle SPIRV_Cross_Input stage_input[3], inout TriangleStream<SPIRV_Cross_Output> geometry_stream)
{
    for (int i = 0; i < 3; i++)
    {
        gl_PositionIn[i] = stage_input[i].gl_PositionIn;
    }
    for (int i = 0; i < 3; i++)
    {
        _18[i] = stage_input[i]._18;
    }
    for (int i = 0; i < 3; i++)
    {
        _26[i] = stage_input[i]._26;
    }
    main_inner(stage_input, geometry_stream);
}
