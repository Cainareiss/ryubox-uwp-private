cbuffer support_buffer : register(b0, space0)
{
    uint support_buffer_1_m0 : packoffset(c0);
    uint support_buffer_1_m1[8] : packoffset(c1);
    float4 support_buffer_1_m2 : packoffset(c9);
    float4 support_buffer_1_m3 : packoffset(c10);
    int support_buffer_1_m4 : packoffset(c11);
    float support_buffer_1_m5[73] : packoffset(c12);
    int4 support_buffer_1_m6 : packoffset(c85);
    int support_buffer_1_m7 : packoffset(c86);
};

cbuffer fp_c3 : register(b2, space0)
{
    float4 fp_c3_1_m0[4096] : packoffset(c0);
};

Texture2D<float4> fp_t_tcb_8 : register(t0, space2);
SamplerState _fp_t_tcb_8_sampler : register(s0, space2);

static float4 _27;
static float4 _29;
static float4 _32;

struct SPIRV_Cross_Input
{
    float4 _29 : TEXCOORD0;
    float4 _27 : TEXCOORD1;
    float4 ryubox_link_input_dummy2 : TEXCOORD2;
    float4 ryubox_link_input_dummy3 : TEXCOORD3;
    float4 ryubox_link_input_dummy4 : TEXCOORD4;
    float4 ryubox_link_input_dummy5 : TEXCOORD5;
    float4 ryubox_link_input_dummy6 : TEXCOORD6;
    float4 ryubox_link_input_dummy7 : TEXCOORD7;
    float4 ryubox_link_input_dummy8 : TEXCOORD8;
    float4 ryubox_link_input_dummy9 : TEXCOORD9;
    float4 ryubox_link_input_dummy10 : TEXCOORD10;
    float4 ryubox_link_input_dummy11 : TEXCOORD11;
    float4 ryubox_link_input_dummy12 : TEXCOORD12;
    float4 ryubox_link_input_dummy13 : TEXCOORD13;
    float4 ryubox_link_input_dummy14 : TEXCOORD14;
    float4 ryubox_link_input_dummy15 : TEXCOORD15;
};

struct SPIRV_Cross_Output
{
    float4 _32 : SV_Target0;
};

void main_inner()
{
    bool _86 = false;
    bool _82 = false;
    float _39 = _27.x;
    float _41 = _27.y;
    float4 _44 = fp_t_tcb_8.Sample(_fp_t_tcb_8_sampler, float2(_39, _41)).xyzw;
    float _46 = _44.x;
    float _48 = _44.y;
    float _50 = _44.z;
    float _52 = _44.w;
    float _54 = _29.x;
    float _56 = _29.y;
    float _58 = _29.z;
    float _60 = _29.w;
    precise float _124 = _46 + fp_c3_1_m0[0].x;
    float _62 = _124;
    precise float _128 = _48 + fp_c3_1_m0[0].y;
    float _64 = _128;
    precise float _132 = _50 + fp_c3_1_m0[0].z;
    float _66 = _132;
    precise float _136 = _52 + fp_c3_1_m0[0].w;
    float _68 = _136;
    precise float _139 = _62 * _54;
    float _70 = _139;
    precise float _142 = _64 * _56;
    float _72 = _142;
    precise float _145 = _66 * _58;
    float _74 = _145;
    precise float _148 = _68 * _60;
    float _76 = _148;
    float _78 = asfloat(support_buffer_1_m1[0]);
    if (!(asint(_78) != 0))
    {
        _32.x = _70;
        _82 = true;
    }
    else
    {
        _32.z = _70;
    }
    _82 = false;
    _32.y = _72;
    float _84 = asfloat(support_buffer_1_m1[0]);
    if (!(asint(_84) != 0))
    {
        _32.z = _74;
        _86 = true;
    }
    else
    {
        _32.x = _74;
    }
    _86 = false;
    _32.w = _76;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    _27 = stage_input._27;
    _29 = stage_input._29;
    main_inner();
    SPIRV_Cross_Output stage_output;
    stage_output._32 = _32;
    return stage_output;
}
